The codes for Single Neuron Model and Network Model are in respective folders.
Each folder has its own ReadMe file.
